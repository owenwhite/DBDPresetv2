# DBDPreset

Dead by Daylight Reshade preset v2

How to install ?

SteamLibrary\steamapps\common\Dead by Daylight\DeadByDaylight\Binaries\Win64
